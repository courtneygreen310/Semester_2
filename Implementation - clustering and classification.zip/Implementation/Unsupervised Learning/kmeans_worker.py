#k means implementation
import numpy as np
def worker_kmeans_partial(partition, centroids):

  """
  partition: tuple (X_part, _)- only features are used.
  centroids: current global centroids, shape (n_clusters, n_features)
  Returns:
    sums: per-cluster sum of points
    counts: per-cluster number of points
  """
  X = partition[0] 
  n_clusters = centroids.shape[0]
  sums = np.zeros_like(centroids)
  counts = np.zeros(n_clusters, dtype=int)
  # Assign each point to nearest centroid
  for x in X:
    distances = np.linalg.norm(centroids- x, axis=1)
    cluster = np.argmin(distances)
    sums[cluster] += x
    counts[cluster] += 1
  return sums, counts