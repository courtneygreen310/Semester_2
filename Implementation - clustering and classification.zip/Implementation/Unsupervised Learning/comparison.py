import time
from sklearn.cluster import KMeans as SKLearnKMeans

from data_utils import generate_kmeans_data
from distributed_kmeans import DistributedKMeans


def compare_with_sklearn(X, y_true, n_clusters, n_workers_list):
  sk_model = SKLearnKMeans(n_clusters=n_clusters, random_state=42)
  start = time.time()
  sk_model.fit(X)
  sk_time = time.time()- start
  sk_inertia = sk_model.inertia_

  print(f"Scikit-learn: inertia={sk_inertia:.2f}, time={sk_time:.4f}s")

  for nw in n_workers_list:
    dist_model = DistributedKMeans(n_clusters=n_clusters, n_workers=nw)
    dist_model.fit(X)
    print(f"Distributed (workers={nw}):inertia={dist_model.inertia_:.2f}, time={dist_model.fit_time_:.4f}s")


if __name__ == "__main__":

    X, y_true = generate_kmeans_data(n_samples=3000, n_clusters=5)

    compare_with_sklearn(X, y_true, n_clusters=5, n_workers_list=[1, 2, 4])