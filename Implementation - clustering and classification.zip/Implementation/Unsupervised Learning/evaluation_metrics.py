#efficiency
#speedup calculations 
#graphs 
import matplotlib.pyplot as plt
import numpy as np

models = ["Sklearn", "D-1", "D-2", "D-4"]

inertia = [67232.63, 184961.01, 146489.94, 67232.63]
time = [4.3653, 5.1039, 3.8037, 3.2421]

x = np.arange(len(models))
width = 0.35

plt.figure(figsize=(10,5))

# Inertia plot
plt.bar(x - width/2, inertia, width, label="Inertia")

# Time plot
plt.bar(x + width/2, time, width, label="Time (s)")

plt.xticks(x, models)
plt.title("K-Means Performance Comparison (Scikit-learn vs Distributed)")
plt.legend()

plt.show()