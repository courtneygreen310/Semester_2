#import library
import numpy as np
from sklearn.datasets import make_blobs, make_classification

#generate synthetic data
def generate_kmeans_data(n_samples = 10000, n_features = 10, n_clusters = 5,
random_state = 42):
  X, y_true = make_blobs(n_samples = n_samples, n_features = n_features, centers = n_clusters, cluster_std = 1.5, random_state = random_state)
  return X, y_true

def generate_logistic_data(n_samples=10000, n_features=20,
n_classes=2, random_state=42):

  X, y = make_classification(n_samples=n_samples, n_features=n_features, n_informative=15, n_redundant=5,
n_classes=n_classes,random_state=random_state)
  
#add intercept term
  X = np.hstack([np.ones((X.shape[0], 1)), X])
  return X, y