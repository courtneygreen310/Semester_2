#master node distributes K means 
import numpy as np
import time
from multiprocessing import Pool
from sklearn.cluster import KMeans as SKLearnKMeans
from data_utils import generate_kmeans_data
from partition_utils import partition_data
from kmeans_worker import worker_kmeans_partial

class DistributedKMeans:
  def __init__(self, n_clusters=5, max_iter=100, tol=1e-4,
    n_workers=4):
    self.n_clusters = n_clusters
    self.max_iter = max_iter
    self.tol = tol
    self.n_workers = n_workers
    self.centroids_ = None
    self.inertia_ = None

  def fit(self, X, y=None):
    y_dummy = np.zeros(X.shape[0]) 
    partitions = partition_data(X, y_dummy, self.n_workers)

    idx = np.random.choice(X.shape[0], self.n_clusters, replace=False)
    centroids = X[idx].copy()

    start_time = time.time()
    with Pool(processes=self.n_workers) as pool:
      for iteration in range(self.max_iter):
        # Distribute work: each worker gets its partition and current centroids
        # Use starmap to pass multiple arguments
        results = pool.starmap(worker_kmeans_partial,[(part, centroids) for part in partitions])
        
        # Aggregate partial sums and counts
        global_sums = np.zeros_like(centroids)
        global_counts = np.zeros(self.n_clusters, dtype=int)

        for sums, counts in results:
          global_sums += sums
          global_counts += counts

        #Compute new centroids (avoid division by zero)
        new_centroids = np.zeros_like(centroids)
        for i in range(self.n_clusters):
          if global_counts[i] > 0:
            new_centroids[i] = global_sums[i] /global_counts[i]
          else:
            # If a cluster loses all points, keep the old centroid
            new_centroids[i] = centroids[i]
            
        # Check convergence
        shift = np.linalg.norm(new_centroids- centroids)
        centroids = new_centroids
        if shift < self.tol:
          print(f"Converged after {iteration+1} iterations")
          break

    self.centroids_ = centroids
    self.inertia_ = self._compute_inertia(X)
    self.fit_time_ = time.time()- start_time
    return self


  def _compute_inertia(self, X):
    """Compute sum of squared distances to nearest centroid."""
    distances = np.min(np.linalg.norm(X[:, np.newaxis] - self.centroids_, axis=2), axis=1)
    return np.sum(distances ** 2)


