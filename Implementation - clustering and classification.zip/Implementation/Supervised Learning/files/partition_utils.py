#data partitioning 
import numpy as np

def partition_data(X, y, n_partitions):

  """Split data into n_partitions chunks."""
  indices = np.arange(X.shape[0])
  np.random.shuffle(indices) # optional: randomize order
  splits = np.array_split(indices, n_partitions)
  partitions = [(X[idx], y[idx]) for idx in splits]
  return partitions
