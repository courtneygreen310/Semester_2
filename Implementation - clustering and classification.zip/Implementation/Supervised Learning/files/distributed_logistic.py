 # distributed_logistic.py
import numpy as np
import time
from multiprocessing import Pool
from sklearn.linear_model import LogisticRegression as SKLogistic
from sklearn.metrics import accuracy_score
from data_utils import generate_logistic_data
from partition_utils import partition_data
from logistic_worker import worker_gradient, sigmoid

class DistributedLogisticRegression:
    def __init__(self, learning_rate=0.01, n_epochs=100, n_workers=4):
        self.lr = learning_rate
        self.n_epochs = n_epochs
        self.n_workers = n_workers
        self.weights_ = None
        self.loss_history_ = []

    def fit(self, X, y):

        # ✅ CREATE PARTITIONS ONCE (HERE)
        partitions = partition_data(X, y, self.n_workers)

        n_features = X.shape[1]
        self.weights_ = np.random.randn(n_features) * 0.01

        start_time = time.time()

        with Pool(processes=self.n_workers) as pool:

            for epoch in range(self.n_epochs):

                gradients = pool.starmap(
                    worker_gradient,
                    [(part, self.weights_) for part in partitions]
                )

                avg_gradient = np.mean(gradients, axis=0)
                self.weights_ -= self.lr * avg_gradient

                if epoch % 10 == 0:
                    loss = self._compute_loss(X, y)
                    self.loss_history_.append(loss)

        self.fit_time_ = time.time() - start_time
        return self

    def predict_proba(self, X):
        z = np.dot(X, self.weights_)
        return sigmoid(z)

    def predict(self, X, threshold=0.5):
        return (self.predict_proba(X) >= threshold).astype(int)

    def _compute_loss(self, X, y):
        eps = 1e-15
        h = np.clip(self.predict_proba(X), eps, 1- eps)
        return-np.mean(y * np.log(h) + (1- y) * np.log(1- h))