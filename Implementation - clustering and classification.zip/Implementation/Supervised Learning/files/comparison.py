import time
import numpy as np
from sklearn.linear_model import LogisticRegression as SKLogistic
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split

from data_utils import generate_logistic_data
from distributed_logistic import DistributedLogisticRegression


def evaluate(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred)
    }


def compare_with_sklearn(X_train, y_train, X_test, y_test, n_workers_list):

    sk_model = SKLogistic(max_iter=1000, solver='lbfgs')

    start = time.time()
    sk_model.fit(X_train, y_train)
    sk_time = time.time() - start

    sk_pred = sk_model.predict(X_test)
    sk_metrics = evaluate(y_test, sk_pred)

    print(f"\nScikit-learn: {sk_metrics}, time={sk_time:.4f}s")

    for nw in n_workers_list:

        dist_model = DistributedLogisticRegression(
            learning_rate=0.01,
            n_epochs=150,
            n_workers=nw
        )

        dist_model.fit(X_train, y_train)

        y_pred = dist_model.predict(X_test)
        metrics = evaluate(y_test, y_pred)

        print(f"\nDistributed (workers={nw}): {metrics}, time={dist_model.fit_time_:.4f}s")


if __name__ == "__main__":

    X, y = generate_logistic_data(add_intercept=True)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # scale using training data only (IMPORTANT)
    mean = X_train[:, 1:].mean(axis=0)
    std = X_train[:, 1:].std(axis=0)

    X_train[:, 1:] = (X_train[:, 1:] - mean) / std
    X_test[:, 1:] = (X_test[:, 1:] - mean) / std

    compare_with_sklearn(
        X_train, y_train,
        X_test, y_test,
        n_workers_list=[1, 2, 4]
    )