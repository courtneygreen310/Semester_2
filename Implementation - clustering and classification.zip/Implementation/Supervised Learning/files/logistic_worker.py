#logistic_worker
import numpy as np

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def worker_gradient(partition, weights):
    """
    partition: (X, y)
    weights: current weight vector (including bias)
    Returns gradient vector of the same shape.
    """
    X, y = partition
    m = X.shape[0]

    z = np.dot(X, weights)
    h = sigmoid(z)

    gradient = np.dot(X.T, (h - y)) / m  # MUST be indented

    return gradient