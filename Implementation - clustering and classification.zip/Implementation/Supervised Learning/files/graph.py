#plot graph for results 
import matplotlib.pyplot as plt

models = ["Sklearn", "1 worker", "2 workers", "4 workers"]
times = [0.0205, 5.2604, 3.6098, 3.6806]

plt.figure(figsize=(8,5))
plt.bar(models, times)

plt.ylabel("Time (seconds)")
plt.title("Training Time Comparison")

plt.show()