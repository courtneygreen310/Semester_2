#!/bin/bash

# Format the HDFS namenode (only does something if not formatted)
hdfs namenode-format-force

# Start SSH service
service ssh start

# If this container is the master...
if [ "$HOSTNAME" = node-master ]; then
	echo "Starting HDFS and YARN on Master..."
	start-dfs.sh
	start-yarn.sh
	echo "Starting Jupyter Notebook..."
	cd /root/lab
	# Start Jupyter, allow root, no token/password for easy access
	jupyter notebook--ip=0.0.0.0--port=8888--no-browser--allow
	root--NotebookApp.token=''--NotebookApp.password='' &
	echo "Master services started."
fi
# Keep the container running
while true; do
	sleep 100
done