import time
from sklearn.linear_model import LogisticRegression as SKLogistic
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

from data_utils import generate_logistic_data
from distributed_logistic import DistributedLogisticRegression


def compare_with_sklearn(X_train, y_train, X_test, y_test, n_workers_list):

    sk_model = SKLogistic(max_iter=1000, solver='lbfgs')

    start = time.time()
    sk_model.fit(X_train, y_train)
    sk_time = time.time() - start

    sk_acc = accuracy_score(y_test, sk_model.predict(X_test))

    print(f"Scikit-learn: accuracy={sk_acc:.4f}, time={sk_time:.4f}s")

    for nw in n_workers_list:

        dist_model = DistributedLogisticRegression(
            learning_rate=0.01,
            n_epochs=100,
            n_workers=nw
        )

        dist_model.fit(X_train, y_train)

        y_pred = dist_model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)

        print(f"Distributed (workers={nw}): accuracy={acc:.4f}, time={dist_model.fit_time_:.4f}s")


if __name__ == "__main__":

    X, y = generate_logistic_data()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    compare_with_sklearn(
        X_train, y_train,
        X_test, y_test,
        n_workers_list=[1, 2, 4]
    )